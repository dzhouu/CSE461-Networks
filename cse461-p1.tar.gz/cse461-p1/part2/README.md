## Lab 1 Part 2: Socket Programming 
All Info for this lab can be found here:  
- [Lab Spec](https://courses.cs.washington.edu/courses/cse461/24au/lab/lab1.html)

### **UW NetIDs:**
Denny Zhou: `Dzhou11`  
Jason Hua: `jhua04`  
Joshua Jung: `jjung04`  

To run the script for client side:
``` shell  
  ./run_server.sh <server_name> <port_number>
```